<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'billal_wp949' );

/** MySQL database username */
define( 'DB_USER', 'billal_wp949' );

/** MySQL database password */
define( 'DB_PASSWORD', 'SqRC81p4).' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'l8tcefohzvp5ovrtb8hf6pu3gqubxhwbwj4rrnx8hreq8dxwdvcxqhws97dzi9gs' );
define( 'SECURE_AUTH_KEY',  '30bkjixlirbxaddlxwxpcwc6ovplrknuzawjqli6c6e1qho7ql7rxhhugz0cqz29' );
define( 'LOGGED_IN_KEY',    'eijshjw4wfcrn7i2ithch12dxixgolnhfinonivhz01pivc7unsefsf1nofbzlc6' );
define( 'NONCE_KEY',        'imcwoxgockae1egjfoxy4459rtmesrrorb0oi0l249nfzafccnzbhtkijqcdosdq' );
define( 'AUTH_SALT',        'gushleobxaip9ninvu9ldzgqsncueuchgqgzmhvwwwqciztieagzxlmmbsm8m3id' );
define( 'SECURE_AUTH_SALT', 'lhei7fisbsaet7ef9q37bfpfs9k5391kgivxevyfd9fqw5dsswaej0qduf4mrayh' );
define( 'LOGGED_IN_SALT',   'gb4u4d32nd8uj3vra1zm51oaeakvfal4xf7msoak6adkw2ryxkhoqenqtzdh6cfa' );
define( 'NONCE_SALT',       'pqdi1375d0sirbcmjrcfyiaknnwzuaytximowwqkw9firwulfmqrenymifrnooxs' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpp4_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
